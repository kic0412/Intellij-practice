package ch07;

public class Starfish {
}
