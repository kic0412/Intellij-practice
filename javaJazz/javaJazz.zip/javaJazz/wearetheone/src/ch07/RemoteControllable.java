package ch07;

public interface RemoteControllable extends Controllable {
    void remoteOn();

    void remoteOff();
}
