package ch04;

public class String4Demo {
    public static void main(String[] args) {
        int i = 7;
        System.out.println("Java" + i);
        System.out.println("Java" + 7);
        System.out.println(7 + 1 + "Java" + 7 + 1);
    }
}
