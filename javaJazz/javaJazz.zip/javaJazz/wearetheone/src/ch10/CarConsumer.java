package ch10;

public interface CarConsumer {
    void accept(Car car);
}