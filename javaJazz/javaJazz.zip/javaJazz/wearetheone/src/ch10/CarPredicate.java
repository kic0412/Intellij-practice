package ch10;

public interface CarPredicate {
    boolean test(Car car);
}